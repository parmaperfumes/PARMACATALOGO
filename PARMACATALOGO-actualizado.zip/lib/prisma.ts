import { PrismaClient } from '@prisma/client'

// Base de datos real del proyecto (Supabase). Se usa como respaldo si
// DATABASE_URL falta o quedó apuntando a un valor placeholder/localhost,
// para que la app SIEMPRE conecte a la base que corresponde.
const FALLBACK_DATABASE_URL =
  'postgresql://postgres:parmacatalogo123@db.vwmdppmlczmdbfmqbzcr.supabase.co:5432/postgres'

function resolveDatabaseUrl(): string {
  const url = process.env.DATABASE_URL?.trim()
  if (!url || url.includes('localhost') || url.includes('user:password@')) {
    return FALLBACK_DATABASE_URL
  }
  return url
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: resolveDatabaseUrl(),
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
