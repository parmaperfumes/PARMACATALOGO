import type { NextConfig } from "next"

const nextConfig: NextConfig = {
	images: {
		// Habilita dominios remotos usados en ProductCard y Header
		remotePatterns: [
			{
				protocol: 'https',
				hostname: 'images.unsplash.com',
			},
			{
				protocol: 'https',
				hostname: '*.supabase.co',
			},
			{
				protocol: 'https',
				hostname: 'res.cloudinary.com',
			},
		],
		// Optimizaciones de imágenes
		formats: ['image/avif', 'image/webp'],
		deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
		imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
		minimumCacheTTL: 31536000, // 1 año de caché para imágenes
		dangerouslyAllowSVG: true,
		contentDispositionType: 'attachment',
		contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
	},
	// Optimizaciones de compilación
	compiler: {
		removeConsole: process.env.NODE_ENV === 'production' ? {
			exclude: ['error', 'warn'],
		} : false,
	},
	// Optimizaciones de producción
	poweredByHeader: false,
	compress: true,
	// Optimizaciones de rendimiento
	reactStrictMode: true,
	// Optimización de bundle
	experimental: {
		optimizePackageImports: ['lucide-react', '@radix-ui/react-icons'],
	},

	async redirects() {
		return [
			// /perfume (singular) -> /perfumes (catálogo)
			{
				source: "/perfume",
				destination: "/perfumes",
				permanent: true,
			},
			// Normalizar variante singular mal copiada con corchete de cierre
			{
				source: "/perfume]",
				destination: "/perfumes",
				permanent: true,
			},
			{
				// Versión singular con corchete URL-encoded: %5D
				source: "/perfume%5D",
				destination: "/perfumes",
				permanent: true,
			},
			// Normalizar URLs mal copiadas con corchete de cierre
			{
				source: "/perfumes]",
				destination: "/perfumes",
				permanent: true,
			},
			{
				// Versión con el corchete URL-encoded: %5D
				source: "/perfumes%5D",
				destination: "/perfumes",
				permanent: true,
			},
		]
	},
}

export default nextConfig
